from setuptools import find_packages, setup

# GPSseq uses a historical TensorFlow Neurite source snapshot provided by its
# maintainer. Its original internal version is 0.2, but its contents are not
# identical to the public PyPI neurite==0.2 wheel.
setup(
    name="neurite",
    version="0.2",
    description="Neurite TensorFlow source snapshot required by GPSseq",
    url="https://github.com/adalca/neurite",
    author="Neurite contributors (upstream)",
    license="Apache-2.0",
    python_requires=">=3.9,<3.10",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["pystrum>=0.2", "packaging"],
)
