# GPSseq-specific Neurite source snapshot

This archive contains the *Python sources provided by the GPSseq developer* from
an installed Neurite environment, with a newly added packaging configuration
(`setup.py` and `pyproject.toml`) so that pip can install it.

The internal and distribution version is **0.2**, but this archive is **not** the
standard PyPI `neurite==0.2` release. It includes `neurite.tf.layers.Constant`
and Keras 3 compatible `MAE`/`MSE` import aliases used by GPSseq.

The original uploaded `neurite.zip` did not include an upstream Git commit ID,
`setup.py` or `LICENSE.md`; **we cannot establish an exact upstream revision**.

Upstream source: https://github.com/adalca/neurite
License: Apache License, Version 2.0 (see LICENSE.md). See the bundled
GPSSEQ_PACKAGING_NOTES.md for provenance and changes.
