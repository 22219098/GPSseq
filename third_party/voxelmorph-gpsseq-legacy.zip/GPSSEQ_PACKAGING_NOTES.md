# GPSseq VoxelMorph source archive - packaging notes

This archive was repacked from the user-provided `voxelmorph-dev.zip` snapshot.
It is NOT the official PyPI VoxelMorph 0.2 distribution.
The upstream Python source code, setup.py and original VoxelMorph License have not been modified.

Packaging changes by GPSseq:
- Flattened two nested `voxelmorph-dev/` directory levels so `setup.py` is at archive root.
- Omitted non-installed large example data in `data/` and GitHub metadata.
- Added `pyproject.toml` for build-system metadata and this packaging note.

Source: https://github.com/voxelmorph/voxelmorph
License: Apache License, Version 2.0 (included as `LICENSE.md`).
Attribution and citation information are available in the included README and citations.bib.

Note: The package internally reports version 0.2 because that is the upstream snapshot's declared version.
It contains `VxmAffineFeatureDetector`, unlike the official PyPI 0.2 wheel.
For scientific reproducibility, record the SHA256 of this archive.
